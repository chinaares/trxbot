<?php
namespace app\libs;

class Bytes
{
    public static function getBytes($str)
    {
        $bytes = [];
        for ($i = 0; $i < strlen($str); $i++) {
            if (ord($str[$i]) >= 128) {
                $byte = ord($str[$i]) - 256;
            } else {
                $byte = ord($str[$i]);
            }
            $bytes[] = $byte;
        }
        return $bytes;
    }

    public static function toString($bytes)
    {
        $str = "";
        foreach ($bytes as $byte) {
            $str .= chr($byte);
        }
        return $str;
    }

    public static function intToBytes($val)
    {
        $bytes = [];
        $bytes[0] = $val >> 24 & 0xFF;
        $bytes[1] = $val >> 16 & 0xFF;
        $bytes[2] = $val >> 8 & 0xFF;
        $bytes[3] = $val & 0xFF;
        return $bytes;
    }

    public static function bytesToInt($bytes, $pos)
    {
        $val = $bytes[$pos] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 1] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 2] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 3] & 0xFF;
        return $val;
    }

    public static function longToBytes($val)
    {
        $bytes = [];
        $bytes[0] = $val >> 56 & 0xFF;
        $bytes[1] = $val >> 48 & 0xFF;
        $bytes[2] = $val >> 40 & 0xFF;
        $bytes[3] = $val >> 32 & 0xFF;
        $bytes[4] = $val >> 24 & 0xFF;
        $bytes[5] = $val >> 16 & 0xFF;
        $bytes[6] = $val >> 8 & 0xFF;
        $bytes[7] = $val & 0xFF;
        return $bytes;
    }

    public static function bytesToLong($bytes, $pos)
    {
        $val = $bytes[$pos] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 1] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 2] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 3] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 4] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 5] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 6] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 7] & 0xFF;
        return $val;
    }


    public static function shortToBytes($val)
    {
        $bytes = [];
        $bytes[1] = $val >> 8 & 0xFF;
        $bytes[0] = $val & 0xFF;
        return $bytes;
    }

    public static function bytesToShort($bytes, $pos)
    {
        $val = 0;
        $val = $bytes[$pos] & 0xFF;
        $val >>= 8;
        $val |= $bytes[$pos + 1] & 0xFF;
        return $val;
    }
}