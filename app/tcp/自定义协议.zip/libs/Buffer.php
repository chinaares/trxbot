<?php

namespace app\libs;
class Buffer
{
    private $buf = [];
    private $pos;

    /**
     * @param $buf
     */
    public function __construct($buf = [])
    {
        $this->buf = $buf;
        $this->pos = 0;
    }

    public function putBytes($bytes, $pos = -1)
    {
        if (count($this->buf) == 0) {
            $this->pos = count($bytes);
        } else {
            $this->pos += count($this->buf);
        }
        if ($pos > -1) {
            $this->pos = $pos;
        }

        array_splice($this->buf, $this->pos, 0, $bytes);
    }

    public function getBytes($len)
    {
        $val = array_slice($this->buf, $this->pos, $len);
        $this->pos += $len;
        return $val;
    }

    public function getAllBytes()
    {
        return $this->buf;
    }

    public function getByte()
    {
        $val = $this->buf[$this->pos];
        $this->pos++;
        return $val;
    }

    public function size()
    {
        return count($this->buf);
    }

    public function reset()
    {
        $this->pos = 0;
    }
}