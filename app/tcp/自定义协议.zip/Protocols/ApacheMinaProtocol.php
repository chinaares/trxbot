<?php

namespace app\Protocols;

use app\libs\Bytes;
use app\libs\Buffer;

class ApacheMinaProtocol
{
    const STREAM_MAGIC = 0xACED;
    const STREAM_VERSION = 5;
    const TC_STRING = 0x74;
    const TC_LONGSTRING = 0x7c;

    public static function input($buffer)
    {
        if (strlen($buffer) < 4) {
            return 0;
        }
        $unpackData = unpack('Nlen', $buffer);
        return $unpackData['len'] + 4;
    }

    public static function decode($buf)
    {
        $buffer = new Buffer(Bytes::getBytes($buf));
        // 获取包长度
        $lenBytes = $buffer->getBytes(4);
        $len = Bytes::bytesToInt($lenBytes, 0);
        // 获取magic
        $streamMagic = $buffer->getBytes(2);
        $streamVersion = $buffer->getBytes(2);
        // 获取tc type
        $tc = $buffer->getByte();
        $dataLen = $len;
        // 判断类型获取数据的长度
        if ($tc == self::TC_STRING) {
            $dataLenByte = $buffer->getBytes(2);
            $dataLen = Bytes::bytesToShort($dataLenByte, 0);
        }
        if ($tc == self::TC_LONGSTRING) {
            $dataLenByte = $buffer->getBytes(4);
            $dataLen = Bytes::bytesToInt($dataLenByte, 0);
        }
        return $buffer->getBytes($dataLen);
    }

    public static function encode($data)
    {
        // 数据字符串转成byte数组
        $bytes = Bytes::getBytes($data);
        // 获取数据长度
        $dataLen = count($bytes);
        // 创建一个buffer临时缓冲区
        $buffer = new Buffer();
        // 写入魔法码
        $buffer->putBytes(Bytes::shortToBytes(self::STREAM_MAGIC));
        // 写入版本
        $buffer->putBytes(Bytes::shortToBytes(self::STREAM_VERSION));
        // 判断长度是要用 short 写还是 int 长度
        if ($dataLen <= 0xFFFF) {
            $buffer->putBytes([self::TC_STRING]);
            $buffer->putBytes(Bytes::shortToBytes($dataLen));
        } else {
            $buffer->putBytes([self::TC_LONGSTRING]);
            $buffer->putBytes(Bytes::intToBytes($dataLen));
        }
        // 把内容写到缓冲区
        $buffer->putBytes($bytes);
        // 获取缓冲区的大小，写到包头
        $buffer->putBytes(Bytes::intToBytes($buffer->size()), 0);
        // 因为workerman底层通过string发送因此转字符串
        return Bytes::toString($buffer->getAllBytes());
    }
}